<?php
include 'db.php';
require_once 'phpqrcode/qrlib.php';

$showModal = false;
$modalMessage = '';
$modalType = '';
$htmlContent = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $student_id = trim($_POST['student_id']);
    $course = $_POST['course'];
    $year_section = $_POST['year_section'];
    $subjects = $_POST['subjects'];

    $check = $conn->prepare("SELECT * FROM students WHERE student_id = ? OR name = ?");
    $check->bind_param("ss", $student_id, $name);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('❌ Student ID or Name already exists.'); window.location.href='register.php';</script>";
        exit;
    } else {
        $stmt = $conn->prepare("INSERT INTO students (student_id, name, course, year_section) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $student_id, $name, $course, $year_section);

        if ($stmt->execute()) {
            foreach ($subjects as $subject_id) {
                $enroll = $conn->prepare("INSERT INTO student_subjects (student_id, subject_id) VALUES (?, ?)");
                $enroll->bind_param("si", $student_id, $subject_id);
                $enroll->execute();
            }

            $qrDir = "qr_codes/";
            if (!file_exists($qrDir)) mkdir($qrDir, 0777, true);
            $filename = $qrDir . $student_id . ".png";
            QRcode::png($student_id, $filename, QR_ECLEVEL_H, 10, 2);

            $showModal = true;
            $modalType = 'success';
            $modalMessage = "Student registered successfully!";

            $htmlContent = "
                <div class='qr-box'>
                    <p><strong>Name:</strong> $name</p>
                    <p><strong>Student ID:</strong> $student_id</p>
                    <p><strong>Course:</strong> $course</p>
                    <p><strong>Year & Section:</strong> $year_section</p>
                    <div class='qr-image'>
                        <img src='$filename' alt='QR Code'>
                    </div>
                    <p class='text-muted'>Scan this QR code to record attendance.</p>
                    <a href='register.php' class='btn btn-primary btn-back'>← Back to Registration</a>
                </div>";
        } else {
            echo "<script>alert('❌ Error: Unable to save student data.'); window.location.href='register.php';</script>";
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang='en'>
<head>
  <meta charset='UTF-8'>
  <title>Generate QR</title>
  <meta name='viewport' content='width=device-width, initial-scale=1.0'>
  <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
  <style>
    body {
      background: #f8f9fa;
      padding: 20px;
      font-family: 'Segoe UI', sans-serif;
    }
    .qr-box {
      background: #fff;
      border-radius: 12px;
      padding: 30px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
      text-align: center;
      max-width: 600px;
      margin: 0 auto;
    }
    .qr-image {
      margin: 20px auto;
      background: #fff;
      padding: 10px;
      border-radius: 10px;
      border: 2px solid #dee2e6;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      width: 280px;
      height: 280px;
    }
    .qr-image img {
      width: 100%;
      height: 100%;
      object-fit: contain;
      image-rendering: pixelated;
    }
  </style>
</head>
<body>
  <?php if (!empty($htmlContent)) echo $htmlContent; ?>

<div class="modal fade" id="popupModal" tabindex="-1" aria-labelledby="popupModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header <?= $modalType === 'success' ? 'bg-success' : 'bg-danger' ?> text-white">
        <h5 class="modal-title" id="popupModalLabel">
          <?= $modalType === 'success' ? '✅ Registration Successful' : '❌ Registration Failed' ?>
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body text-center">
        <?php if ($modalType === 'success'): ?>
          <div class="mb-3">
            <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="green" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
              <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM6.97 11.03a.75.75 0 0 0 1.07.02l3.992-3.992a.75.75 0 1 0-1.06-1.06L7.5 9.439 6.03 7.97a.75.75 0 1 0-1.06 1.06l2 2z"/>
            </svg>
          </div>
          <p class="fs-5 fw-semibold"><?= $modalMessage ?></p>
          <p class="text-muted">The student has been added to the system and is now ready for attendance monitoring.</p>
        <?php else: ?>
          <div class="mb-3">
            <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="red" class="bi bi-x-circle-fill" viewBox="0 0 16 16">
              <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM4.646 4.646a.5.5 0 0 0-.708.708L7.293 8l-3.355 3.354a.5.5 0 1 0 .708.708L8 8.707l3.354 3.355a.5.5 0 0 0 .708-.708L8.707 8l3.355-3.354a.5.5 0 0 0-.708-.708L8 7.293 4.646 4.646z"/>
            </svg>
          </div>
          <p class="fs-5 fw-semibold"><?= $modalMessage ?></p>
          <p class="text-muted">Please try again or contact the administrator if the issue persists.</p>
        <?php endif; ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


  <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js'></script>
  <?php if ($showModal): ?>
  <script>
    var popup = new bootstrap.Modal(document.getElementById('popupModal'));
    popup.show();
  </script>
  <?php endif; ?>
</body>
</html>
