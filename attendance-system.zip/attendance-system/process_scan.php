<?php
require 'db.php'; // Make sure this file connects to your database
session_start();

// 🔹 Get student ID and subject ID
$student_id = $_POST['student_id'] ?? '';
$subject_id = $_SESSION['subject_id'] ?? null;

// 🔹 Validate input
if (!$student_id || !$subject_id) {
    echo "❌ Error: Missing student ID or subject ID.";
    exit;
}

// 🔹 Check if student is enrolled in the selected subject
$check = $conn->prepare("SELECT * FROM student_subjects WHERE student_id = ? AND subject_id = ?");
if (!$check) {
    echo "❌ SQL Prepare Error: " . $conn->error;
    exit;
}
$check->bind_param("si", $student_id, $subject_id);
$check->execute();
$result = $check->get_result();

if ($result->num_rows === 0) {
    echo "❌ Student is not enrolled in this subject.";
    exit;
}

// 🔹 Set timezone to Philippines
date_default_timezone_set("Asia/Manila");
$date = date("Y-m-d");
$time_now = date("H:i:s");

// 🔹 Check if student has already logged in today
$check_attendance = $conn->prepare("SELECT * FROM attendance WHERE student_id = ? AND subject_id = ? AND date = ?");
$check_attendance->bind_param("sis", $student_id, $subject_id, $date);
$check_attendance->execute();
$res = $check_attendance->get_result();

if ($res->num_rows > 0) {
    // ✅ Student already has a record today — update Time Out
    $update = $conn->prepare("UPDATE attendance SET time_out = ? WHERE student_id = ? AND subject_id = ? AND date = ?");
    $update->bind_param("ssis", $time_now, $student_id, $subject_id, $date);
    $update->execute();

    $display = date("h:i A", strtotime($time_now));
    echo "✅ Time Out recorded at $display.";

} else {
    // ✅ No record yet — insert Time In
    $insert = $conn->prepare("INSERT INTO attendance (student_id, subject_id, date, time_in) VALUES (?, ?, ?, ?)");
    $insert->bind_param("siss", $student_id, $subject_id, $date, $time_now);
    $insert->execute();

    $display = date("h:i A", strtotime($time_now));
    echo "✅ Time In recorded at $display.";
}

$conn->close();
?>
