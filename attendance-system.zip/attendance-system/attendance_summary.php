<?php include 'db.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Attendance Monitoring System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <!-- XLSX for export -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

  <style>
  @media print {
    body { background: white !important; color: black !important; font-size: 12pt !important; line-height: 1.0 !important; }
    nav, form, .btn, .no-print { display: none !important; }
    .print-only { display: block !important; }
    .print-header { margin-top: 20px; margin-bottom: 15px; text-align: center !important; }
    .print-header h2 { margin: 5px 0; font-size: 20pt; font-weight: bold; }
    table { width: 100%; border-collapse: collapse !important; border: 1px solid black !important; }
    table, th, td { border: 1px solid black !important; }
    th, td { padding: 6px !important; text-align: center !important; background: none !important; color: black !important; line-height: 1.0 !important; }
    thead { background: none !important; }
    .signature-col { display: table-cell !important; }
    td.name-col, li.absent-name { text-align: left !important; } /* Left align names in print */
  }

  .navbar-brand img { height: 30px; margin-right: 10px; }
  .print-only { display: none; }
  .print-header { text-align: left; }
  .print-header h2 { margin-top: 0; }
  .signature-col { display: none; }

  th, td { text-align: center; vertical-align: middle; }
  td.name-col { text-align: left !important; } /* Left align Student Name column */
  li.absent-name { text-align: left !important; } /* Left align Absent Students list */

  thead.table-lightblue th {
    background-color: #cce5ff;
    color: #000;
  }
  </style>
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4 no-print">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center" href="index.php">
      <img src="images/cst.png" alt="Logo">
      <span>Attendance Monitoring System</span>
    </a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="register.php"><i class="bi bi-person-plus-fill me-1"></i> Register</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_panel.php"><i class="bi bi-gear-fill me-1"></i> Control Panel</a></li>
        <li class="nav-item"><a class="nav-link" href="attendance_summary.php"><i class="bi bi-clipboard-data-fill me-1"></i> Summary</a></li>
        <li class="nav-item"><a class="nav-link" href="logout.php"><i class="bi bi-box-arrow-right me-1"></i> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container py-4">
  <div class="print-only text-center mb-3">
    <img src="images/gsc_header.png" alt="Guimaras State University Header" style="max-width:100%; height:auto;">
  </div>

  <div class="print-header mb-3"><h2>Attendance Summary</h2></div>

  <!-- Filter Form -->
  <form method="GET" class="row g-2 align-items-end mb-4 no-print">
    <div class="col-md-3">
      <input type="text" name="student_name" class="form-control" placeholder="Enter Student Name"
             value="<?php echo isset($_GET['student_name']) ? htmlspecialchars($_GET['student_name']) : ''; ?>">
    </div>

    <div class="col-md-3">
      <select name="subject_id" class="form-select">
        <option value="">-- Select Subject (with Course & Section) --</option>
        <?php
        $subjects = $conn->query("SELECT id, subject_name, course, year_section FROM subjects ORDER BY course, year_section, subject_name ASC");
        while ($sub = $subjects->fetch_assoc()) {
          $label = "{$sub['subject_name']} ({$sub['course']} - {$sub['year_section']})";
          $selected = (isset($_GET['subject_id']) && $_GET['subject_id'] == $sub['id']) ? 'selected' : '';
          echo "<option value=\"" . intval($sub['id']) . "\" $selected>" . htmlspecialchars($label) . "</option>";
        }
        ?>
      </select>
    </div>

    <!-- Date Range Filter -->
    <div class="col-md-2">
      <label class="form-label">From:</label>
      <input type="date" name="start_date" class="form-control" value="<?php echo isset($_GET['start_date']) ? htmlspecialchars($_GET['start_date']) : ''; ?>">
    </div>
    <div class="col-md-2">
      <label class="form-label">To:</label>
      <input type="date" name="end_date" class="form-control" value="<?php echo isset($_GET['end_date']) ? htmlspecialchars($_GET['end_date']) : ''; ?>">
    </div>

    <div class="col-md-2 d-grid">
      <button type="submit" class="btn btn-info"><i class="bi bi-funnel-fill me-1"></i> Apply Filters</button>
    </div>
  </form>

<?php
// --- Build query based on filters ---
$student_name = isset($_GET['student_name']) ? $conn->real_escape_string($_GET['student_name']) : '';
$subject_id = isset($_GET['subject_id']) ? intval($_GET['subject_id']) : 0;
$start_date = isset($_GET['start_date']) ? $conn->real_escape_string($_GET['start_date']) : '';
$end_date = isset($_GET['end_date']) ? $conn->real_escape_string($_GET['end_date']) : '';

$query = "SELECT a.date, a.time_in, a.time_out, st.student_id, st.name, s.subject_name, s.course, s.year_section
          FROM attendance a
          JOIN students st ON a.student_id = st.student_id
          JOIN subjects s ON a.subject_id = s.id
          WHERE 1";

$showHeading = "";

// heading for student or subject (print-only)
if (!empty($student_name)) {
  $showHeading = "<h5 class='mb-3 print-only'>Summary for Student: <strong>" . htmlspecialchars($student_name) . "</strong></h5>";
}
if (!empty($subject_id)) {
  $subjectQuery = $conn->query("SELECT subject_name, course, year_section FROM subjects WHERE id = $subject_id");
  $subjectInfo = $subjectQuery ? $subjectQuery->fetch_assoc() : null;
  if ($subjectInfo) {
    $label = "{$subjectInfo['subject_name']} ({$subjectInfo['course']} - {$subjectInfo['year_section']})";
    $showHeading = "<h5 class='mb-3 print-only'>Summary for Subject: <strong>" . htmlspecialchars($label) . "</strong></h5>";
    $query .= " AND s.id = $subject_id";
  }
}

// date filters
if (!empty($start_date) && !empty($end_date)) {
  $query .= " AND DATE(a.date) BETWEEN '$start_date' AND '$end_date'";
} elseif (!empty($start_date)) {
  $query .= " AND DATE(a.date) = '$start_date'";
}

$query .= " ORDER BY s.course, s.year_section, a.date DESC";

$result = $conn->query($query);

// Fetch rows into array so we can compute counts before printing cards
$rows = [];
$attendanceStudents = []; // keyed by student_id
$presentCount = 0;

if ($result) {
  while ($r = $result->fetch_assoc()) {
    $rows[] = $r;
    // count present (time_in not empty)
    if (!empty($r['time_in'])) {
      $presentCount++;
    }
    // collect attendance student ids (use student_id column value)
    $attendanceStudents[$r['student_id']] = $r['name'];
  }
}

// Determine if this is a daily summary (single day)
$isDailySummary = false;
if (!empty($start_date) && !empty($end_date)) {
  if ($start_date === $end_date) $isDailySummary = true;
} elseif (!empty($start_date) && empty($end_date)) {
  $isDailySummary = true;
}

// Compute enrolled / absent only when subject_id selected and it's a daily summary
$totalEnrolled = 0;
$absentStudents = [];
$absentCount = 0;

if ($subject_id && $isDailySummary) {
  $enrolledQuery = $conn->query("
    SELECT st.student_id, st.name 
    FROM student_subjects ss
    JOIN students st ON ss.student_id = st.student_id
    WHERE ss.subject_id = $subject_id
    ORDER BY st.name ASC
  ");

  if ($enrolledQuery) {
    $totalEnrolled = $enrolledQuery->num_rows;
    while ($en = $enrolledQuery->fetch_assoc()) {
      if (!array_key_exists($en['student_id'], $attendanceStudents)) {
        $absentStudents[] = $en['name'];
      }
    }
  }
  $absentCount = count($absentStudents);
}
?>

<?php if (!isset($result) || $result === false): ?>
  <div class="alert alert-danger">Query Error: <?= htmlspecialchars($conn->error) ?></div>
<?php else: ?>

  <?php if (count($rows) > 0): ?>

<!-- Cards (appear under buttons) -->
<?php if ($isDailySummary && $subject_id): ?>
  <div class="row mt-3 no-print">
    <div class="col-md-4 mb-2">
      <div class="card text-center" style="border: 2px solid #0d6efd; border-radius: 10px;">
        <div class="card-body">
          <h6 class="card-title text-primary">
            <i class="bi bi-people-fill me-1"></i> Total Enrolled
          </h6>
          <p class="card-text fs-4 fw-bold text-primary"><?= intval($totalEnrolled) ?></p>
        </div>
      </div>
    </div>

    <div class="col-md-4 mb-2">
      <div class="card text-center" style="border: 2px solid #198754; border-radius: 10px;">
        <div class="card-body">
          <h6 class="card-title text-success">
            <i class="bi bi-check-circle-fill me-1"></i> Total Present
          </h6>
          <p class="card-text fs-4 fw-bold text-success"><?= intval($presentCount) ?></p>
        </div>
      </div>
    </div>

    <div class="col-md-4 mb-2">
      <div class="card text-center" style="border: 2px solid #dc3545; border-radius: 10px;">
        <div class="card-body">
          <h6 class="card-title text-danger">
            <i class="bi bi-x-circle-fill me-1"></i> Total Absent
          </h6>
          <p class="card-text fs-4 fw-bold text-danger"><?= intval($absentCount) ?></p>
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>


    <!-- Print-only heading (keeps web interface clean) -->
    <?= $showHeading ?>

  <!-- Buttons -->
<div class="mb-3 no-print d-flex justify-content-end gap-2">
  <button onclick="exportToExcel()" class="btn btn-success">
    <i class="bi bi-file-earmark-excel-fill me-1"></i> Export to Excel
  </button>
  <button onclick="printTable()" class="btn btn-secondary">
    <i class="bi bi-printer-fill me-1"></i> Print
  </button>
</div>


    <!-- Table -->
    <div class="table-responsive mt-3">
      <table class="table table-bordered table-striped" id="attendanceTable">
        <thead class="table-lightblue">
          <tr>
            <th>Date</th>
            <th>Student Name</th>
            <th>Subject</th>
            <th>Course</th>
            <th>Year & Section</th>
            <th>Time In</th>
            <th>Time Out</th>
            <th class="signature-col">Signature</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $row): 
            $timeIn = $row['time_in'] ? date("h:i A", strtotime($row['time_in'])) : '';
            $timeOut = $row['time_out'] ? date("h:i A", strtotime($row['time_out'])) : '';
          ?>
            <tr>
              <td><?= htmlspecialchars($row['date']) ?></td>
              <td class="name-col"><?= htmlspecialchars($row['name']) ?></td>
              <td><?= htmlspecialchars($row['subject_name']) ?></td>
              <td><?= htmlspecialchars($row['course']) ?></td>
              <td><?= htmlspecialchars($row['year_section']) ?></td>
              <td><?= $timeIn ?></td>
              <td><?= $timeOut ?></td>
              <td class="signature-col"></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <!-- Improved Absent Students card (appears under buttons and above table on screen) -->
    <?php if ($isDailySummary && $subject_id): ?>
      <?php if ($absentCount > 0): ?>
        <div class="card border-danger mt-4 no-print">
          <div class="card-header bg-danger text-white d-flex justify-content-between align-items-center">
            <span><i class="bi bi-person-dash-fill me-2"></i> Absent Students</span>
          </div>
          <div class="card-body" style="max-height:200px; overflow-y:auto;">
            <ul class="list-group list-group-flush">
              <?php foreach ($absentStudents as $absent): ?>
                <li class="list-group-item">
                  <i class="bi bi-x-circle text-danger me-2"></i><?= htmlspecialchars($absent) ?>
                </li>
              <?php endforeach; ?>
            </ul>
          </div>
        </div>
      <?php else: ?>
        <div class="alert alert-success mt-3 no-print">
          <i class="bi bi-check-circle-fill me-2"></i> All students are present!
        </div>
      <?php endif; ?>
    <?php endif; ?>

  <?php else: ?>
    <div class="alert alert-warning">No records found for the selected filters.</div>
  <?php endif; ?>

<?php endif; ?>

</div>

<script>
function exportToExcel() {
  const table = document.getElementById("attendanceTable");
  if (!table) {
    alert("No table to export.");
    return;
  }
  const wb = XLSX.utils.table_to_book(table, {sheet:"Attendance"});
  XLSX.writeFile(wb, "attendance_summary.xlsx");
}
function printTable() { window.print(); }
</script>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
