<?php include 'db.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Attendance Monitoring System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
  <style>
  @media print {
    body { background: white !important; color: black !important; font-size: 12pt !important; line-height: 1.0 !important; }
    nav, form, .btn, .no-print { display: none !important; }
    .print-only { display: block !important; }
    .print-header { margin-top: 20px; margin-bottom: 15px; text-align: center !important; }
    .print-header h2 { margin: 5px 0; font-size: 20pt; font-weight: bold; }
    table { width: 100%; border-collapse: collapse !important; border: 1px solid black !important; }
    table, th, td { border: 1px solid black !important; }
    th, td { padding: 6px !important; text-align: center !important; background: none !important; color: black !important; line-height: 1.0 !important; }
    thead { background: none !important; }
    .signature-col { display: table-cell !important; }
    td.name-col, li.absent-name { text-align: left !important; } /* Left align names in print */
  }

  .navbar-brand img { height: 30px; margin-right: 10px; }
  .print-only { display: none; }
  .print-header { text-align: left; }
  .print-header h2 { margin-top: 0; }
  .signature-col { display: none; }

  th, td { text-align: center; vertical-align: middle; }
  td.name-col { text-align: left !important; } /* Left align Student Name column */
  li.absent-name { text-align: left !important; } /* Left align Absent Students list */

  thead.table-lightblue th {
    background-color: #cce5ff;
    color: #000;
  }
  </style>
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4 no-print">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center" href="index.php">
      <img src="images/cst.png" alt="Logo">
      <span>Attendance Monitoring System</span>
    </a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="register.php"><i class="bi bi-person-plus-fill me-1"></i> Register</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_panel.php"><i class="bi bi-gear-fill me-1"></i> Control Panel</a></li>
        <li class="nav-item"><a class="nav-link" href="attendance_summary.php"><i class="bi bi-clipboard-data-fill me-1"></i> Summary</a></li>
        <li class="nav-item"><a class="nav-link" href="logout.php"><i class="bi bi-box-arrow-right me-1"></i> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container py-4">
  <div class="print-only text-center mb-3">
    <img src="images/gsc_header.png" alt="Guimaras State University Header" style="max-width:100%; height:auto;">
  </div>

  <div class="print-header mb-3"><h2>Attendance Summary</h2></div>

  <!-- Filter Form -->
  <form method="GET" class="row g-2 align-items-end mb-4 no-print">
    <div class="col-md-3">
      <input type="text" name="student_name" class="form-control" placeholder="Enter Student Name"
             value="<?php echo isset($_GET['student_name']) ? htmlspecialchars($_GET['student_name']) : ''; ?>">
    </div>

    <div class="col-md-3">
      <select name="subject_id" class="form-select">
        <option value="">-- Select Subject (with Course & Section) --</option>
        <?php
        $subjects = $conn->query("SELECT id, subject_name, course, year_section FROM subjects ORDER BY course, year_section, subject_name ASC");
        while ($sub = $subjects->fetch_assoc()) {
          $label = "{$sub['subject_name']} ({$sub['course']} - {$sub['year_section']})";
          $selected = (isset($_GET['subject_id']) && $_GET['subject_id'] == $sub['id']) ? 'selected' : '';
          echo "<option value='{$sub['id']}' $selected>$label</option>";
        }
        ?>
      </select>
    </div>

    <div class="col-md-2">
      <label class="form-label">From:</label>
      <input type="date" name="start_date" class="form-control" value="<?php echo isset($_GET['start_date']) ? $_GET['start_date'] : ''; ?>">
    </div>
    <div class="col-md-2">
      <label class="form-label">To:</label>
      <input type="date" name="end_date" class="form-control" value="<?php echo isset($_GET['end_date']) ? $_GET['end_date'] : ''; ?>">
    </div>

    <div class="col-md-2 d-grid">
      <button type="submit" class="btn btn-info"><i class="bi bi-funnel-fill me-1"></i> Apply Filters</button>
    </div>
  </form>

<?php
// sanitize inputs
$student_name = isset($_GET['student_name']) ? $conn->real_escape_string($_GET['student_name']) : '';
$subject_id   = isset($_GET['subject_id']) ? intval($_GET['subject_id']) : 0;
$start_date   = isset($_GET['start_date']) ? $conn->real_escape_string($_GET['start_date']) : '';
$end_date     = isset($_GET['end_date']) ? $conn->real_escape_string($_GET['end_date']) : '';

// -------------------- Attendance Records --------------------
$query = "SELECT DATE(a.time_in) AS date, a.time_in, a.time_out, st.student_id, st.name, 
                 s.subject_name, s.course, s.year_section
          FROM attendance a
          JOIN students st ON a.student_id = st.student_id
          JOIN subjects s ON a.subject_id = s.id
          WHERE 1";

if (!empty($student_name)) {
  $query .= " AND st.name LIKE '%$student_name%'";
}
if (!empty($subject_id)) {
  $query .= " AND s.id = $subject_id";
}
if (!empty($start_date) && !empty($end_date)) {
  $query .= " AND DATE(a.time_in) BETWEEN '$start_date' AND '$end_date'";
} elseif (!empty($start_date)) {
  $query .= " AND DATE(a.time_in) = '$start_date'";
}

$query .= " ORDER BY s.course, s.year_section, DATE(a.time_in) DESC";
$result = $conn->query($query);

// -------------------- Stats (Total, Present, Absent) --------------------
$total_students = $present_students = $absent_students = 0;
$absent_list = [];

if (!empty($subject_id)) {
    // Get all enrolled students for this subject
    $enrolled_sql = "SELECT st.student_id, st.name
                     FROM student_subjects ss
                     JOIN students st ON ss.student_id = st.student_id
                     WHERE ss.subject_id = $subject_id";
    $enrolled_res = $conn->query($enrolled_sql);

    $enrolled_ids = [];
    if ($enrolled_res && $enrolled_res->num_rows > 0) {
        while ($row = $enrolled_res->fetch_assoc()) {
            $enrolled_ids[$row['student_id']] = $row['name'];
        }
    }

    $total_students = count($enrolled_ids);

    if ($total_students > 0) {
        // Get present students
        $present_sql = "SELECT DISTINCT a.student_id
                        FROM attendance a
                        WHERE a.subject_id = $subject_id";
        if (!empty($start_date) && !empty($end_date)) {
            $present_sql .= " AND DATE(a.time_in) BETWEEN '$start_date' AND '$end_date'";
        } elseif (!empty($start_date)) {
            $present_sql .= " AND DATE(a.time_in) = '$start_date'";
        }
        $present_res = $conn->query($present_sql);

        $present_ids = [];
        if ($present_res && $present_res->num_rows > 0) {
            while ($p = $present_res->fetch_assoc()) {
                $present_ids[] = $p['student_id'];
            }
        }

        $present_students = count($present_ids);

        // Absent = enrolled - present
        $absent_ids = array_diff(array_keys($enrolled_ids), $present_ids);
        $absent_students = count($absent_ids);

        foreach ($absent_ids as $aid) {
            $absent_list[] = ["student_id" => $aid, "name" => $enrolled_ids[$aid]];
        }
    }
}
?>

<!-- Stats Cards -->
<?php if (!empty($subject_id)): ?>
<div class="row mb-4">
  <div class="col-md-4"><div class="card text-center"><div class="card-body"><h5 class="card-title">Total Students</h5><p class="fs-4 fw-bold text-primary"><?php echo $total_students; ?></p></div></div></div>
  <div class="col-md-4"><div class="card text-center"><div class="card-body"><h5 class="card-title">Present</h5><p class="fs-4 fw-bold text-success"><?php echo $present_students; ?></p></div></div></div>
  <div class="col-md-4"><div class="card text-center"><div class="card-body"><h5 class="card-title">Absent</h5><p class="fs-4 fw-bold text-danger"><?php echo $absent_students; ?></p></div></div></div>
</div>
<?php endif; ?>

<!-- Attendance Table -->
<div class="mb-3 no-print">
  <button onclick="exportToExcel()" class="btn btn-success"><i class="bi bi-file-earmark-excel-fill me-1"></i> Export to Excel</button>
  <button onclick="printTable()" class="btn btn-secondary"><i class="bi bi-printer-fill me-1"></i> Print</button>
</div>

<div class="table-responsive">
<table class="table table-bordered table-striped text-center" id="attendanceTable">
  <thead class="table-lightblue">
    <tr>
      <th>Date</th>
      <th>Student Name</th>
      <th>Subject</th>
      <th>Course</th>
      <th>Year & Section</th>
      <th>Time In</th>
      <th>Time Out</th>
      <th class="signature-col">Signature</th>
    </tr>
  </thead>
  <tbody>
    <?php
    if ($result && $result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        $timeIn = $row['time_in'] ? date("h:i A", strtotime($row['time_in'])) : '';
        $timeOut = $row['time_out'] ? date("h:i A", strtotime($row['time_out'])) : '';
        echo "<tr>
                <td>{$row['date']}</td>
                <td class='name-col'>{$row['name']}</td>
                <td>{$row['subject_name']}</td>
                <td>{$row['course']}</td>
                <td>{$row['year_section']}</td>
                <td>$timeIn</td>
                <td>$timeOut</td>
                <td class='signature-col'></td>
              </tr>";
      }
    } else {
      echo "<tr><td colspan='8' class='text-center'>No records found for the selected filters.</td></tr>";
    }
    ?>
  </tbody>
</table>
</div>

<!-- Absent Students Section at the Bottom -->
<?php if (!empty($absent_list)): ?>
  <div class="card mt-4">
    <div class="card-header bg-danger text-white"><strong>Absentee List</strong></div>
    <div class="card-body">
      <ul class="list-unstyled mb-0">
        <?php foreach ($absent_list as $a): ?>
          <li class="absent-name"><?php echo htmlspecialchars($a['name']); ?> </li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
<?php endif; ?>

<script>
function exportToExcel() {
  const table = document.getElementById("attendanceTable");
  const wb = XLSX.utils.table_to_book(table, {sheet:"Attendance"});
  XLSX.writeFile(wb, "attendance_summary.xlsx");
}
function printTable() { window.print(); }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</div>
</body>
</html>
