<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $subject_name = $_POST['subject_name'];
  $course = $_POST['course'];
  $year_section = $_POST['year_section'];

  $stmt = $conn->prepare("INSERT INTO subjects (subject_name, course, year_section) VALUES (?, ?, ?)");
  $stmt->bind_param("sss", $subject_name, $course, $year_section);

  if ($stmt->execute()) {
    header("Location: admin_panel.php?success=1");
  } else {
    echo "Failed to save subject.";
  }
}
?>