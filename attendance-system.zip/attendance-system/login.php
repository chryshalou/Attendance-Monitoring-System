<?php
session_start();
require 'db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $stmt = $conn->prepare("SELECT id, username, password, role FROM users WHERE username = ? LIMIT 1");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            if (password_verify($password, $row['password'])) {
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['username'] = $row['username'];
                $_SESSION['role'] = $row['role'];
                if ($row['role'] === 'instructor') {
                    header('Location: admin_panel.php');
                } else {
                    header('Location: pacd_dashboard.php');
                }
                exit;
            }
        }
        $error = "Invalid username or password.";
    } else {
        $error = "Please enter username and password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login — Attendance Monitoring System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap & Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body {
      background: #f8f9fa; /* light gray for contrast */
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      font-family: "Segoe UI", sans-serif;
    }
    .card {
      border-radius: 15px;
      border: none;
    }
    .card-header {
      background: #0062E6;
      color: white;
      text-align: center;
      padding: 1.2rem;
      border-radius: 15px 15px 0 0;
    }
    .form-control {
      border-radius: 10px;
      padding: 12px;
      font-size: 1rem;
    }
    .btn-primary {
      border-radius: 10px;
      font-size: 1.1rem;
      padding: 12px;
      background: #0062E6;
      border: none;
      transition: 0.3s;
    }
    .btn-primary:hover {
      background: #004bbd;
    }
    .input-group-text {
      background: #f1f1f1;
      border-right: 0;
    }
    .input-group .form-control {
      border-left: 0;
    }
    .toggle-password {
      cursor: pointer;
      border-left: 0;
    }
  </style>
</head>
<body>

<div class="card shadow-lg" style="width: 100%; max-width: 420px; background: white;">
  <div class="card-header">
    <h3><i class="bi bi-box-arrow-in-right"></i> Attendance System Login</h3>
  </div>
  <div class="card-body p-4">
    <?php if ($error): ?>
      <div class="alert alert-danger text-center">
        <i class="bi bi-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?>
      </div>
    <?php endif; ?>
    <form method="POST">
      <div class="mb-3">
        <label class="form-label">Username</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-person"></i></span>
          <input type="text" name="username" class="form-control" placeholder="Enter your username" required>
        </div>
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-lock"></i></span>
          <input type="password" name="password" id="password" class="form-control" placeholder="Enter your password" required>
          <span class="input-group-text toggle-password" onclick="togglePassword()">
            <i class="bi bi-eye" id="toggleIcon"></i>
          </span>
        </div>
      </div>
      <button class="btn btn-primary w-100"><i class="bi bi-box-arrow-in-right"></i> Login</button>
    </form>
    <hr>
    <p class="text-center mb-0">
      <i class="bi bi-person-plus"></i> No account? 
      <a href="user_register.php" class="text-decoration-none">Create one</a>
    </p>
  </div>
</div>

<script>
function togglePassword() {
  const passwordInput = document.getElementById("password");
  const toggleIcon = document.getElementById("toggleIcon");
  if (passwordInput.type === "password") {
    passwordInput.type = "text";
    toggleIcon.classList.remove("bi-eye");
    toggleIcon.classList.add("bi-eye-slash");
  } else {
    passwordInput.type = "password";
    toggleIcon.classList.remove("bi-eye-slash");
    toggleIcon.classList.add("bi-eye");
  }
}
</script>

</body>
</html>
