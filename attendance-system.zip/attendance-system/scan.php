<?php
session_start();

// Handle AJAX request
if (isset($_POST['student_id']) && isset($_SESSION['subject_id'])) {
    require 'db.php';

    $student_id = $_POST['student_id'];
    $subject_id = $_SESSION['subject_id'];

    // Check enrollment
    $check = $conn->prepare("SELECT * FROM student_subjects WHERE student_id = ? AND subject_id = ?");
    $check->bind_param("si", $student_id, $subject_id);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows === 0) {
        echo "❌ Student is not enrolled in this subject";
        exit;
    }

    // Timezone
    date_default_timezone_set("Asia/Manila");
    $date = date("Y-m-d");
    $time_now = date("H:i:s");

    // Check today's attendance
    $check_attendance = $conn->prepare("SELECT * FROM attendance WHERE student_id = ? AND subject_id = ? AND date = ?");
    $check_attendance->bind_param("sis", $student_id, $subject_id, $date);
    $check_attendance->execute();
    $res = $check_attendance->get_result();

    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();
        if (!empty($row['time_out'])) {
            echo "⚠️ You have already logged out today at " . date("h:i A", strtotime($row['time_out'])) . ".";
        } else {
            $update = $conn->prepare("UPDATE attendance SET time_out = ? WHERE student_id = ? AND subject_id = ? AND date = ?");
            $update->bind_param("ssis", $time_now, $student_id, $subject_id, $date);
            $update->execute();
            echo "✅ Time Out recorded at " . date("h:i A", strtotime($time_now)) . ".";
        }
    } else {
        $insert = $conn->prepare("INSERT INTO attendance (student_id, subject_id, date, time_in) VALUES (?, ?, ?, ?)");
        $insert->bind_param("siss", $student_id, $subject_id, $date, $time_now);
        $insert->execute();
        echo "✅ Time In recorded at " . date("h:i A", strtotime($time_now)) . ".";
    }

    $conn->close();
    exit;
}

// Handle subject selection
if (isset($_POST['subject_id'])) {
    $_SESSION['subject_id'] = $_POST['subject_id'];
} elseif (!isset($_SESSION['subject_id'])) {
    die("Error: No subject selected. Go back to the admin panel.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Scan QR Code</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="js/html5-qrcode.min.js"></script>

<style>
/* Mirror the video preview so it looks like a selfie camera */
#reader video {
    transform: scaleX(-1);
    -webkit-transform: scaleX(-1);
    -moz-transform: scaleX(-1);
}
</style>
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
<div class="container">
<a class="navbar-brand d-flex align-items-center gap-2" href="index.php">
<img src="images/cst.png" alt="Logo" style="height: 32px;">
<span>Attendance Monitoring System</span>
</a>
</div>
</nav>

<div class="container py-5">
<h2 class="mb-4 text-center">Scan Student QR Code</h2>

<div class="card p-4 shadow-sm mx-auto" style="max-width: 400px;">
    <div id="reader" style="width: 100%;"></div>
    <div class="mt-3" id="scan-result" style="display: none;">
        <div id="result-message" class="alert" role="alert"></div>
    </div>
</div>

<div class="text-center mt-4">
<a href="admin_panel.php" class="btn btn-secondary">← Back to Subject Selection</a>
</div>
</div>

<script>
let isScanning = true;

function speakMessage(message, callback) {
    const utterance = new SpeechSynthesisUtterance(message);
    utterance.lang = "en-US";
    utterance.rate = 1;
    utterance.pitch = 1;
    utterance.onend = function() {
        if (callback) callback();
    };
    window.speechSynthesis.speak(utterance);
}

function onScanSuccess(decodedText) {
    if (!isScanning) return;
    isScanning = false;

    const now = Date.now();
    const lastScanTime = localStorage.getItem("lastScanTime_" + decodedText);

    if (lastScanTime && (now - lastScanTime < 900000)) {
        const messageBox = document.getElementById('result-message');
        const scanResult = document.getElementById('scan-result');
        messageBox.className = "alert alert-warning";
        messageBox.textContent = "You already scanned. Please wait 15 minutes before scanning again.";
        scanResult.style.display = 'block';
        setTimeout(() => { isScanning = true; }, 2000);
        return;
    }

    // AJAX request to same page
    const formData = new FormData();
    formData.append('student_id', decodedText);

    fetch('', {
        method: 'POST',
        body: formData
    })
    .then(res => res.text())
    .then(data => {
        const messageBox = document.getElementById('result-message');
        const scanResult = document.getElementById('scan-result');

        if (data.includes("not enrolled")) {
            messageBox.className = "alert alert-danger";
            messageBox.textContent = "Student is not enrolled in this subject";
            speakMessage("Student is not enrolled in this subject", () => { isScanning = true; });

        } else if (data.includes("Time In")) {
            messageBox.className = "alert alert-success";
            messageBox.textContent = data;
            localStorage.setItem("lastScanTime_" + decodedText, now);
            speakMessage("Log in Successful", () => { isScanning = true; });

        } else if (data.includes("Time Out recorded")) {
            messageBox.className = "alert alert-success";
            messageBox.textContent = data;
            speakMessage("Log out Successful", () => { isScanning = true; });

        } else if (data.includes("already logged out")) {
            messageBox.className = "alert alert-warning";
            messageBox.textContent = data;
            speakMessage("You have already logged out today", () => { isScanning = true; });
        }

        scanResult.style.display = 'block';
    })
    .catch(err => { console.error(err); isScanning = true; });
}

let scanner = new Html5QrcodeScanner("reader", {
    fps: 10,
    qrbox: 250,
    rememberLastUsedCamera: true,
    showTorchButtonIfSupported: true,
    supportedScanTypes: [Html5QrcodeScanType.SCAN_TYPE_CAMERA]
});
scanner.render(onScanSuccess);
</script>
</body>
</html>
