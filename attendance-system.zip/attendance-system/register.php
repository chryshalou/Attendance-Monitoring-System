<?php
session_start();
require 'db.php';

// ✅ Restrict access to instructors only
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'instructor') {
  header("Location: login.php");
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Student Registration — Attendance System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body { background-color: #f8f9fa; }
    .subject-card { cursor: pointer; transition: transform 0.2s, background-color 0.2s; }
    .subject-card.selected { background-color: #0d6efd; color: white; transform: scale(1.05); }
    .subject-card:hover { transform: scale(1.02); }
    .form-section { margin-bottom: 1.5rem; }
    .form-label { font-weight: 500; }
  </style>
</head>
<body>

<!-- ✅ Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4 shadow-sm">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center gap-2" href="index.php">
      <img src="images/cst.png" alt="Logo" style="height: 32px;">
      <span>Attendance Monitoring System</span>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="register.php">
            <i class="bi bi-person-plus-fill me-1"></i> Register
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="admin_panel.php">
            <i class="bi bi-gear-fill me-1"></i> Control Panel
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="attendance_summary.php">
            <i class="bi bi-clipboard-data-fill me-1"></i> Summary
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="logout.php">
            <i class="bi bi-box-arrow-right me-1"></i> Logout
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container py-4">
  <h2 class="mb-4">Student Registration</h2>

  <form method="POST" action="generate_qr.php" class="card p-4 shadow-sm bg-white">
    <!-- Student Information -->
    <div class="form-section">
      <div class="mb-3">
        <label class="form-label">Full Name</label>
        <input type="text" name="name" class="form-control" placeholder="Juan Dela Cruz" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Student ID</label>
        <input type="text" name="student_id" class="form-control" placeholder="2023-0-0123" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Course</label>
        <select name="course" class="form-select" required>
          <option value="">-- Select Course --</option>
          <option value="BSCS">BS in Computer Science</option>
          <option value="BSIT">BS in Information Technology</option>
          <option value="BSIS">BS in Information Systems</option>
        </select>
      </div>

      <div class="mb-3">
        <label class="form-label">Year & Section</label>
        <select name="year_section" class="form-select" required>
          <option value="">-- Select Year & Section --</option>
          <option value="1A">1A</option>
          <option value="1B">1B</option>
          <option value="1C">1C</option>
          <option value="1D">1D</option>
          <option value="2A">2A</option>
          <option value="2B">2B</option>
          <option value="2C">2C</option>
          <option value="2D">2D</option>
          <option value="3A">3A</option>
          <option value="3B">3B</option>
          <option value="3C">3C</option>
          <option value="3D">3D</option>
          <option value="3E">3E</option>
          <option value="4A">4A</option>
          <option value="4B">4B</option>
          <option value="4C">4C</option>
        </select>
      </div>
    </div>

    <!-- Subjects Selection -->
    <div class="form-section">
      <label class="form-label mb-2">Subjects Enrolled</label>
      <div class="row g-3">
        <?php
        $subjects = $conn->query("SELECT id, subject_name, course, year_section FROM subjects ORDER BY subject_name ASC");
        while ($row = $subjects->fetch_assoc()):
          $label = "{$row['course']} - {$row['year_section']} - {$row['subject_name']}";
        ?>
        <div class="col-6 col-md-4 col-lg-3">
          <div class="card subject-card p-2 text-center" data-id="<?= $row['id'] ?>">
            <i class="bi bi-book me-1"></i> <?= htmlspecialchars($label) ?>
          </div>
        </div>
        <?php endwhile; ?>
      </div>
      <div id="selected-subjects"></div>
      <div class="form-text mt-2">Click a card to select or deselect a subject.</div>
    </div>

    <button type="submit" class="btn btn-primary mt-3 w-100">
      <i class="bi bi-person-plus-fill me-1"></i> Register Student
    </button>
  </form>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {
  const cards = document.querySelectorAll(".subject-card");
  const container = document.getElementById("selected-subjects");

  cards.forEach(card => {
    card.addEventListener("click", function () {
      const subjectId = this.getAttribute("data-id");
      const isSelected = this.classList.toggle("selected");

      if (isSelected) {
        const input = document.createElement("input");
        input.type = "hidden";
        input.name = "subjects[]";
        input.value = subjectId;
        input.id = "sub-" + subjectId;
        container.appendChild(input);
      } else {
        const input = document.getElementById("sub-" + subjectId);
        if (input) input.remove();
      }
    });
  });
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
