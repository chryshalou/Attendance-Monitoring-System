<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'pacd') {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>PACD — Scan</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <script src="js/html5-qrcode.min.js"></script>
  <style>
    #reader {
      width: 100%;
      max-width: 480px;
      margin: 0 auto;
    }
    /* ✅ Mirror the QR scanner feed */
    #reader video {
      transform: scaleX(-1);
    }
    /* Navbar logo size */
    .navbar-brand img {
      height: 32px;
      margin-right: 8px;
    }
  </style>
</head>
<body class="bg-light">

<!-- ✅ Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm mb-4">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center gap-2" href="pacd_dashboard.php">
      <img src="images/GSU.png" alt="Logo"> <!-- Your logo here -->
      <span></i> Entry and Exit Monitoring</span>
    </a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link active" href="pacd_dashboard.php"><i class="bi bi-list"></i> Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="pacd_scan.php"><i class="bi bi-qr-code-scan"></i> Scan</a></li>
        <li class="nav-item"><a class="nav-link" href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container py-4">
  <div class="row g-4">
    <!-- ✅ Scanner -->
    <div class="col-lg-6">
      <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
          <i class="bi bi-camera-video"></i> QR Code Scanner
        </div>
        <div class="card-body text-center">
          <p class="text-muted">Align the student’s QR code inside the box to log attendance.</p>
<button class="btn btn-dark mb-3" onclick="openExternalDisplay()">
  <i class="bi bi-display"></i> Open External Display
</button>

          <div id="reader"></div>
        </div>
      </div>
    </div>


    <!-- ✅ Result -->
    <div class="col-lg-6">
      <div class="card shadow-sm">
        <div class="card-header bg-success text-white">
          <i class="bi bi-person-check"></i> Scan Result
        </div>
        <div class="card-body" id="result">
          <div class="alert alert-info text-center mb-0">
            <i class="bi bi-hourglass-split"></i> Waiting for scan…
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
let scanningPaused = false;
let lastScans = {};
const cooldownSeconds = 60;
let externalWindow = null; // ✅ external display window

// ✅ Function to open external display
function openExternalDisplay() {
  if (!externalWindow || externalWindow.closed) {
    externalWindow = window.open("", "ScanResultDisplay", "width=900,height=700");
    externalWindow.document.write(`
      <html>
      <head>
        <title>Scan Result Display</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
          body {
            background-color: white;
            color: black;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
          }
          #external-result {
            text-align: center;
            padding: 20px;
          }
          #external-result h1 {
            font-size: 6rem;   /* HUGE text for names */
            font-weight: bold;
          }
          #external-result h2 {
            font-size: 4rem;   /* Sub text (e.g. login/logout) */
            font-weight: bold;
            margin-top: 20px;
          }
          #external-result .alert {
            font-size: 3rem;   /* Alerts big */
            padding: 30px;
          }
          #external-result img {
            max-width: 500px;   /* Bigger student photo */
            max-height: 500px;
            width: auto;
            height: auto;
            border-radius: 20px;
            margin-top: 30px;
            box-shadow: 0px 6px 20px rgba(0,0,0,0.4);
          }
        </style>
      </head>
      <body>
        <div id="external-result">
          <h1 class="text-primary">Waiting for scan…</h1>
        </div>
      </body>
      </html>
    `);
    externalWindow.document.close();
  }
}

// ✅ Function to update both local & external result
function updateResult(content) {
  document.getElementById('result').innerHTML = content;
  if (externalWindow && !externalWindow.closed) {
    externalWindow.document.getElementById('external-result').innerHTML = content;
  }
}

function onScanSuccess(decodedText) {
  if (scanningPaused) return; 

  const now = Date.now();
  const lastScanTime = lastScans[decodedText] || 0;
  const secondsSinceLastScan = (now - lastScanTime) / 1000;

  if (secondsSinceLastScan < cooldownSeconds) {
    updateResult(`
      <div class="alert alert-warning text-center mb-0">
        <i class="bi bi-exclamation-triangle"></i> Please wait ${Math.ceil(cooldownSeconds - secondsSinceLastScan)}s before scanning again.
      </div>`);
    return;
  }

  lastScans[decodedText] = now;
  scanningPaused = true;

  const formData = new FormData();
  formData.append('student_id', decodedText);

  fetch('pacd_process_scan.php', { method: 'POST', body: formData })
    .then(r => r.text())
    .then(txt => {
      updateResult(txt); // ✅ updates local + external display

      if (txt.toLowerCase().includes("login")) {
        new Audio("sounds/welcome.mp3").play();
        speakText("Welcome, time in recorded.");
      } else if (txt.toLowerCase().includes("logout")) {
        new Audio("sounds/goodbye.mp3").play();
        speakText("Goodbye, time out recorded.");
      }
    })
    .catch(e => {
      updateResult("<div class='alert alert-danger'><i class='bi bi-x-circle'></i> Error: " + e + "</div>");
    })
    .finally(() => {
      setTimeout(() => {
        scanningPaused = false;
      }, 2000);
    });
}

function onScanError(_) {}

function speakText(message) {
  if ('speechSynthesis' in window) {
    const utterance = new SpeechSynthesisUtterance(message);
    utterance.lang = 'en-US';
    speechSynthesis.speak(utterance);
  }
}

let html5QrcodeScanner = new Html5QrcodeScanner('reader', { fps: 10, qrbox: 250 });
html5QrcodeScanner.render(onScanSuccess, onScanError);
</script>

</body>
</html>
