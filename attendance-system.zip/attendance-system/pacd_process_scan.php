<?php
session_start();
require 'db.php'; // connect to DB

// ✅ Set PHP timezone to Philippine Time
date_default_timezone_set('Asia/Manila');

// ✅ Set MySQL session timezone to Philippine Time
$conn->query("SET time_zone = '+08:00'");

// ✅ Restrict access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'pacd') {
    exit("Unauthorized access.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['student_id'])) {
    $student_id = $conn->real_escape_string($_POST['student_id']);

    // For DB insertion
    $nowDb = date("Y-m-d H:i:s");       
    // For display in Philippine format
    $displayTime = date("M d, Y h:i:s A"); 

    // 1️⃣ Check if student exists
    $check = $conn->query("SELECT * FROM students WHERE student_id = '$student_id'")
        or die("SQL Error: " . $conn->error);
    if ($check->num_rows === 0) {
        echo "<div class='alert alert-danger text-center'>❌ Student not found.</div>";
        exit;
    }
    $student = $check->fetch_assoc();

    // 2️⃣ Get last log
    $lastLog = $conn->query("SELECT * FROM attendance_logs 
                             WHERE student_id = '$student_id' 
                             ORDER BY log_time DESC LIMIT 1");

    $action = "login";  // default action
    $allowLog = true;   // flag if log should be inserted

    if ($lastLog && $lastLog->num_rows > 0) {
        $last = $lastLog->fetch_assoc();

        $lastTime = strtotime($last['log_time']);
        $nowTime  = strtotime($nowDb);
        $diffMinutes = ($nowTime - $lastTime) / 60; // difference in minutes

        if ($last['action'] === 'login') {
            if ($diffMinutes >= 15) {
                $action = "logout"; // allow logout after 15 mins
            } else {
                $allowLog = false; // too soon
            }
        } else {
            // last action was logout → next should be login
            $action = "login";
        }
    }

    // 3️⃣ Insert record if allowed
    if ($allowLog) {
        $stmt = $conn->prepare("INSERT INTO attendance_logs (student_id, action, log_time) VALUES (?, ?, ?)")
            or die("Prepare Failed: " . $conn->error);
        $stmt->bind_param("sss", $student_id, $action, $nowDb);
        $stmt->execute();
        $stmt->close();

        $statusMsg = "✅ " . ucfirst($action) . " recorded at $displayTime";
        $badgeColor = ($action === 'login') ? "bg-success" : "bg-danger";

        // ✅ Voice message text
        $voiceMsg = ($action === 'login') ? "Welcome {$student['name']}" : "Goodbye {$student['name']}";
    } else {
        $statusMsg = "⏳ Please wait 15 minutes before logging out.";
        $badgeColor = "bg-warning text-dark";
        $voiceMsg = "";
    }

    // 4️⃣ Student photo
    	$photo = !empty($student['image']) ? $student['image'] : "images/default.png";


    // 5️⃣ Always return card with student info
    echo "
    <div class='card shadow-sm'>
      <div class='card-body text-center'>
        <img src='$photo' alt='Student Photo' class='rounded-circle mb-3' 
             style='width:120px;height:120px;object-fit:cover;'>
        <h5 class='mb-1'>{$student['name']}</h5>
        <p class='mb-1'>{$student['course']} - {$student['year_section']}</p>
        <span class='badge $badgeColor fs-6'>$statusMsg</span>
      </div>
    </div>

    <script>
      (function(){
        let msg = " . json_encode($voiceMsg) . ";
        if(msg){
          let utterance = new SpeechSynthesisUtterance(msg);
          utterance.lang = 'en-US';
          utterance.rate = 1;
          window.speechSynthesis.speak(utterance);
        }
      })();
    </script>
    ";
}
?>
