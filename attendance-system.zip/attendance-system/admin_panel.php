<?php
include 'db.php';

$subject_name = '';
$course = '';
$year_section = '';
$showModal = false;
$modalMessage = '';
$active_tab = 'scan';
$search_student = ''; // <-- for search

/** Preserve active tab if passed in URL */
if (isset($_GET['tab'])) {
  $active_tab = $_GET['tab'];
}

/** Always-available Year & Section options */
$sections = ['1A','1B','1C','1D','2A','2B','2C','2D','3A','3B','3C','3D','3E','4A','4B','4C'];

/* -------------------- ADD SUBJECT -------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_subject'])) {
  $subject_name = trim($_POST['subject_name']);
  $course = $_POST['course'] ?? '';
  $year_section = $_POST['year_section'] ?? '';

  $stmt = $conn->prepare("INSERT INTO subjects (subject_name, course, year_section) VALUES (?, ?, ?)");
  $stmt->bind_param("sss", $subject_name, $course, $year_section);

  if ($stmt->execute()) {
    $modalMessage = "✅ Subject added successfully!";
  } else {
    $modalMessage = "❌ Failed to save subject. " . $conn->error;
  }
  $stmt->close();
  $showModal = true;
  $active_tab = 'subjects';
}

/* -------------------- DELETE SUBJECT -------------------- */
if (isset($_GET['delete_subject'])) {
  $id = intval($_GET['delete_subject']);
  $stmt = $conn->prepare("DELETE FROM subjects WHERE id = ?");
  $stmt->bind_param("i", $id);
  if ($stmt->execute()) {
    $modalMessage = "🗑️ Subject deleted successfully!";
  } else {
    $modalMessage = "❌ Failed to delete subject. " . $conn->error;
  }
  $stmt->close();
  $showModal = true;
  $active_tab = 'subjects';
}

/* -------------------- UPDATE SUBJECT -------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_subject'])) {
  $id = intval($_POST['id']);
  $subject_name = trim($_POST['subject_name']);
  $course = $_POST['course'] ?? '';
  $year_section = $_POST['year_section'] ?? '';

  $stmt = $conn->prepare("UPDATE subjects SET subject_name=?, course=?, year_section=? WHERE id=?");
  $stmt->bind_param("sssi", $subject_name, $course, $year_section, $id);

  if ($stmt->execute()) {
    $modalMessage = "✏️ Subject updated successfully!";
  } else {
    $modalMessage = "❌ Failed to update subject. " . $conn->error;
  }
  $stmt->close();
  $showModal = true;
  $active_tab = 'subjects';
}

/* -------------------- DELETE STUDENT -------------------- */
if (isset($_GET['delete_student'])) {
  $id = intval($_GET['delete_student']);
  $stmt = $conn->prepare("DELETE FROM students WHERE id = ?");
  $stmt->bind_param("i", $id);
  if ($stmt->execute()) {
    $modalMessage = "🗑️ Student deleted successfully!";
  } else {
    $modalMessage = "❌ Failed to delete student. " . $conn->error;
  }
  $stmt->close();
  $showModal = true;
  $active_tab = 'students';
}

/* -------------------- UPDATE STUDENT -------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_student'])) {
  $id = intval($_POST['id']);
  $name = trim($_POST['name']);
  $student_id = trim($_POST['student_id']);
  $student_course = $_POST['student_course'] ?? '';
  $student_year_section = $_POST['student_year_section'] ?? '';

  $stmt = $conn->prepare("UPDATE students SET name=?, student_id=?, course=?, year_section=? WHERE id=?");
  $stmt->bind_param("ssssi", $name, $student_id, $student_course, $student_year_section, $id);

  if ($stmt->execute()) {
    $modalMessage = "✏️ Student updated successfully!";
  } else {
    $modalMessage = "❌ Failed to update student. " . $conn->error;
  }
  $stmt->close();
  $showModal = true;
  $active_tab = 'students';
}

/* -------------------- FETCH DATA -------------------- */
$subjects_for_select = $conn->query("SELECT id, subject_name, course, year_section FROM subjects ORDER BY course, year_section, subject_name ASC");
$subjects_for_manage = $conn->query("SELECT id, subject_name, course, year_section FROM subjects ORDER BY course, year_section, subject_name ASC");

/** Fetch Students - with search filter */
if (isset($_GET['search_student']) && !empty(trim($_GET['search_student']))) {
  $search_student = trim($_GET['search_student']);
  $stmt = $conn->prepare("SELECT id, name, student_id, course, year_section FROM students WHERE name LIKE ? ORDER BY course, year_section, name ASC");
  $like = "%" . $search_student . "%";
  $stmt->bind_param("s", $like);
  $stmt->execute();
  $students_for_manage = $stmt->get_result();
} else {
  $students_for_manage = $conn->query("SELECT id, name, student_id, course, year_section FROM students ORDER BY course, year_section, name ASC");
}

if (!$students_for_manage) {
  die("SQL Error (students): " . $conn->error);
}

$subjects_rows = [];
while ($r = $subjects_for_manage->fetch_assoc()) {
  $subjects_rows[] = $r;
}

$students_rows = [];
$students_for_manage->data_seek(0);
while ($r = $students_for_manage->fetch_assoc()) {
  $students_rows[] = $r;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Attendance Monitoring System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

<!-- Navbar with icons -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center gap-2" href="index.php">
      <img src="images/cst.png" alt="Logo" style="height: 32px;">
      <span>Attendance Monitoring System</span>
    </a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="register.php">
            <i class="bi bi-person-plus-fill me-1"></i> Register
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="admin_panel.php">
            <i class="bi bi-gear-fill me-1"></i> Control Panel
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="attendance_summary.php">
            <i class="bi bi-clipboard-data-fill me-1"></i> Summary
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="logout.php">
            <i class="bi bi-box-arrow-right me-1"></i> Logout
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Main Content -->
<div class="container py-4">
  <h2 class="mb-4">Class Management</h2>

  <!-- Tabs -->
  <ul class="nav nav-tabs mb-3" id="adminTab" role="tablist">
    <li class="nav-item"><button class="nav-link <?= $active_tab==='scan'?'active':'' ?>" data-bs-toggle="tab" data-bs-target="#scan">Scan QR Code</button></li>
    <li class="nav-item"><button class="nav-link <?= $active_tab==='subjects'?'active':'' ?>" data-bs-toggle="tab" data-bs-target="#subjects">Subjects</button></li>
    <li class="nav-item"><button class="nav-link <?= $active_tab==='students'?'active':'' ?>" data-bs-toggle="tab" data-bs-target="#students">Students</button></li>
  </ul>

  <div class="tab-content">
    <!-- Scan Tab -->
    <div class="tab-pane fade <?= $active_tab==='scan'?'show active':'' ?>" id="scan">
      <form method="POST" action="scan.php" class="card p-4 shadow-sm">
        <div class="mb-3">
          <label class="form-label">Select Class</label>
          <select name="subject_id" class="form-select" required>
            <option value="">-- Select Subject / Course / Year & Section --</option>
            <?php while ($row = $subjects_for_select->fetch_assoc()): ?>
              <option value="<?= $row['id'] ?>"><?= $row['course'] ?> - <?= $row['year_section'] ?> - <?= $row['subject_name'] ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <button class="btn btn-primary"><i class="bi bi-upc-scan me-1"></i> Start Scanning</button>
      </form>
    </div>

    <!-- Subjects Tab -->
    <div class="tab-pane fade <?= $active_tab==='subjects'?'show active':'' ?>" id="subjects">
      <form method="POST" class="card p-4 shadow-sm mb-4">
        <input type="hidden" name="add_subject" value="1">
        <h5><i class="bi bi-book me-1"></i> Add Subject</h5>
        <input type="text" name="subject_name" class="form-control mb-2" placeholder="Subject Name" required>
        <select name="course" class="form-select mb-2" required>
          <option value="">-- Select Course --</option>
          <option value="BSIT">BSIT</option>
          <option value="BSCS">BSCS</option>
          <option value="BSIS">BSIS</option>
        </select>
        <select name="year_section" class="form-select mb-2" required>
          <option value="">-- Select Year & Section --</option>
          <?php foreach($sections as $sec): ?>
            <option value="<?= $sec ?>"><?= $sec ?></option>
          <?php endforeach; ?>
        </select>
        <button class="btn btn-primary"><i class="bi bi-plus-circle me-1"></i> Add Subject</button>
      </form>

      <div class="card p-4 shadow-sm">
        <h5><i class="bi bi-card-list me-1"></i> Subjects List</h5>
        <table class="table table-bordered">
          <thead class="table-primary">
            <tr><th>Subject Name</th><th>Course</th><th>Year & Section</th><th>Actions</th></tr>
          </thead>
          <tbody>
            <?php foreach($subjects_rows as $row): ?>
              <tr>
                <td><?= $row['subject_name'] ?></td>
                <td><?= $row['course'] ?></td>
                <td><?= $row['year_section'] ?></td>
                <td>
                  <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editSubjectModal<?= $row['id'] ?>"><i class="bi bi-pencil-square me-1"></i> Edit</button>
                  <a href="?delete_subject=<?= $row['id'] ?>&tab=subjects" class="btn btn-danger btn-sm" onclick="return confirm('Delete this subject?')"><i class="bi bi-trash me-1"></i> Delete</a>
                </td>
              </tr>

              <!-- Edit Subject Modal -->
              <div class="modal fade" id="editSubjectModal<?= $row['id'] ?>" tabindex="-1">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <form method="POST">
                      <div class="modal-header">
                        <h5 class="modal-title"><i class="bi bi-pencil-square me-1"></i> Edit Subject</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                      </div>
                      <div class="modal-body">
                        <input type="hidden" name="update_subject" value="1">
                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                        <input type="text" name="subject_name" class="form-control mb-2" value="<?= $row['subject_name'] ?>" required>
                        <select name="course" class="form-select mb-2" required>
                          <option value="BSIT" <?= $row['course']=='BSIT'?'selected':'' ?>>BSIT</option>
                          <option value="BSCS" <?= $row['course']=='BSCS'?'selected':'' ?>>BSCS</option>
                          <option value="BSIS" <?= $row['course']=='BSIS'?'selected':'' ?>>BSIS</option>
                        </select>
                        <select name="year_section" class="form-select mb-2" required>
                          <?php foreach($sections as $sec): ?>
                            <option value="<?= $sec ?>" <?= $row['year_section']==$sec?'selected':'' ?>><?= $sec ?></option>
                          <?php endforeach; ?>
                        </select>
                      </div>
                      <div class="modal-footer">
                        <button type="submit" class="btn btn-primary"><i class="bi bi-check-circle me-1"></i> Save Changes</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Students Tab -->
    <div class="tab-pane fade <?= $active_tab==='students'?'show active':'' ?>" id="students">
      <div class="card p-4 shadow-sm">
        <h5><i class="bi bi-people-fill me-1"></i> Students List</h5>

        <!-- Search Form -->
<form method="GET" class="mb-3 d-flex">
  <input type="hidden" name="tab" value="students">
  <input type="text" name="search_student" class="form-control me-2" placeholder="Search by name..." value="<?= htmlspecialchars($search_student) ?>">
  
  <button class="btn btn-primary d-flex align-items-center">
    <i class="bi bi-search me-1"></i> Search
  </button>

  <?php if ($search_student): ?>
    <a href="admin_panel.php?tab=students" class="btn btn-secondary ms-2 d-flex align-items-center">
      <i class="bi bi-x-circle me-1"></i> Reset
    </a>
  <?php endif; ?>
</form>


        <table class="table table-bordered">
          <thead class="table-primary">
            <tr><th>ID Number</th><th>Name</th><th>Course</th><th>Year & Section</th><th>Actions</th></tr>
          </thead>
          <tbody>
            <?php if (count($students_rows) > 0): ?>
              <?php foreach($students_rows as $row): ?>
                <tr>
                  <td><?= $row['student_id'] ?></td>
                  <td><?= $row['name'] ?></td>
                  <td><?= $row['course'] ?></td>
                  <td><?= $row['year_section'] ?></td>
                  <td>
                    <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editStudentModal<?= $row['id'] ?>"><i class="bi bi-pencil-square me-1"></i> Edit</button>
                    <a href="?delete_student=<?= $row['id'] ?>&tab=students" class="btn btn-danger btn-sm" onclick="return confirm('Delete this student?')"><i class="bi bi-trash me-1"></i> Delete</a>
                  </td>
                </tr>

                <!-- Edit Student Modal -->
                <div class="modal fade" id="editStudentModal<?= $row['id'] ?>" tabindex="-1">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <form method="POST">
                        <div class="modal-header">
                          <h5 class="modal-title"><i class="bi bi-pencil-square me-1"></i> Edit Student</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                          <input type="hidden" name="update_student" value="1">
                          <input type="hidden" name="id" value="<?= $row['id'] ?>">
                          <input type="text" name="name" class="form-control mb-2" value="<?= $row['name'] ?>" required>
                          <input type="text" name="student_id" class="form-control mb-2" value="<?= $row['student_id'] ?>" required>
                          <select name="student_course" class="form-select mb-2" required>
                            <option value="BSIT" <?= $row['course']=='BSIT'?'selected':'' ?>>BSIT</option>
                            <option value="BSCS" <?= $row['course']=='BSCS'?'selected':'' ?>>BSCS</option>
                            <option value="BSIS" <?= $row['course']=='BSIS'?'selected':'' ?>>BSIS</option>
                          </select>
                          <select name="student_year_section" class="form-select mb-2" required>
                            <?php foreach($sections as $sec): ?>
                              <option value="<?= $sec ?>" <?= $row['year_section']==$sec?'selected':'' ?>><?= $sec ?></option>
                            <?php endforeach; ?>
                          </select>
                        </div>
                        <div class="modal-footer">
                          <button type="submit" class="btn btn-primary"><i class="bi bi-check-circle me-1"></i> Save Changes</button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>

              <?php endforeach; ?>
            <?php else: ?>
              <tr><td colspan="5" class="text-center">No students found.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php if ($showModal): ?>
<!-- Feedback Modal -->
<div class="modal fade show" id="feedbackModal" tabindex="-1" style="display:block; background:rgba(0,0,0,.5);">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow-lg">
      <div class="modal-header 
        <?= strpos($modalMessage, '❌')!==false ? 'bg-danger text-white' : (strpos($modalMessage, '🗑️')!==false ? 'bg-warning text-dark' : 'bg-success text-white') ?>">
        <h5 class="modal-title">
          <?= strpos($modalMessage, '❌')!==false ? 'Error' : (strpos($modalMessage, '🗑️')!==false ? 'Deleted' : 'Success') ?>
        </h5>
      </div>
      <div class="modal-body fs-5">
        <?= $modalMessage ?>
      </div>
      <div class="modal-footer">
        <a href="admin_panel.php?tab=<?= $active_tab ?>" class="btn btn-secondary">Close</a>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
