<?php
session_start();
require 'db.php'; // connect to DB

// ✅ Set PHP timezone to Philippine Time
date_default_timezone_set('Asia/Manila');

// ✅ Restrict access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'pacd') {
    exit("Unauthorized access.");
}

// ✅ Get filters
$filter_date = $_GET['date'] ?? date('Y-m-d');
$filter_name = $_GET['student_name'] ?? '';

// ✅ Prepare query safely
$sql = "SELECT l.id, l.student_id, l.action, l.log_time, s.name, s.course, s.year_section 
        FROM attendance_logs l
        JOIN students s ON l.student_id = s.student_id
        WHERE DATE(l.log_time) = ?";

$params = [$filter_date];
$types = "s";

if (!empty($filter_name)) {
    $sql .= " AND s.name LIKE ?";
    $types .= "s";
    $params[] = "%$filter_name%";
}

$sql .= " ORDER BY l.log_time DESC";

$stmt = $conn->prepare($sql);

if ($stmt) {
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    $logs = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
} else {
    die("❌ SQL Error: " . $conn->error);
}

// ✅ Compute summary
$total_logs = count($logs);
$total_login = count(array_filter($logs, fn($l) => $l['action'] === 'login'));
$total_logout = count(array_filter($logs, fn($l) => $l['action'] === 'logout'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Entry and Exit Monitoring Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body { background-color: #f8f9fa; }
    .navbar-brand img { height: 32px; }
    .badge-login { background-color: #28a745; }
    .badge-logout { background-color: #dc3545; }
    .table td, .table th { vertical-align: middle; }

    .table-hover tbody tr:hover {
      background-color: #f1f9ff;
    }

    /* ✅ Sticky filter bar */
    .filter-bar {
      position: sticky;
      top: 0;
      z-index: 100;
      background: #fff;
      padding: 10px;
      border-radius: 8px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }

  .summary-card {
  background-color: white; /* white background */
  border: 2px solid;       /* border color will come from Bootstrap classes */
  border-radius: 8px;
  padding: 20px;
  text-align: center;
}

    .summary-login { background: transparent; }
    .summary-logout { background: transparent; }
    .summary-total { background: transparent; }
  </style>
</head>
<body>

<!-- ✅ Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center gap-2" href="pacd_dashboard.php">
      <img src="images/GSU.png" alt="Logo">
      <span>Entry and Exit Monitoring</span>
    </a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link active" href="pacd_dashboard.php"><i class="bi bi-list"></i> Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="pacd_scan.php"><i class="bi bi-qr-code-scan"></i> Scan</a></li>
        <li class="nav-item"><a class="nav-link" href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- ✅ Page Content -->
<div class="container py-4">

  <!-- ✅ Filters -->
  <div class="filter-bar mb-4">
    <form class="row g-2 align-items-center" method="GET">
      <div class="col-md-5">
        <input type="text" name="student_name" class="form-control" placeholder="Enter Student Name" 
               value="<?php echo htmlspecialchars($filter_name); ?>">
      </div>
      <div class="col-md-3">
        <input type="date" name="date" class="form-control" value="<?php echo htmlspecialchars($filter_date); ?>">
      </div>
      
      <div class="col-md-4 d-flex gap-2">
       <button class="btn flex-fill" style="background-color: #00CCFF; color: black;">
  <i class="bi bi-funnel-fill me-1"></i> Apply Filter
</button>

        <a href="pacd_dashboard.php" class="btn btn-secondary flex-fill" style="background-color: lightgray; border-color: lightgray; color: black;">
  <i class="bi bi-arrow-repeat"></i> Reset
</a>

      </div>
    </form>
  </div>

 <!-- ✅ Summary Cards -->
<div class="row mb-2">
  <div class="col-md-4">
    <div class="summary-card summary-total text-primary border-primary">
      <i class="bi bi-people-fill me-1"></i> <strong>Total Logs</strong><br>
      <span class="fs-4 fw-bold"><?php echo $total_logs; ?></span>
    </div>
  </div>
  <div class="col-md-4">
    <div class="summary-card summary-login text-success border-success">
      <i class="bi bi-box-arrow-in-right-fill me-1"></i> <strong>Logins</strong><br>
      <span class="fs-4 fw-bold"><?php echo $total_login; ?></span>
    </div>
  </div>
  <div class="col-md-4">
    <div class="summary-card summary-logout text-danger border-danger">
      <i class="bi bi-box-arrow-left-fill me-1"></i> <strong>Logouts</strong><br>
      <span class="fs-4 fw-bold"><?php echo $total_logout; ?></span>
    </div>
  </div>
</div>


  <!-- ✅ Action Buttons -->
  <div class="mb-2 d-flex justify-content-end gap-2">
  <!-- Print button in dark gray -->
  <button class="btn" style="background-color: #616569; color: #fff;" onclick="window.print()" title="Print summary and logs">
    <i class="bi bi-printer"></i> Print
  </button>

  <!-- Export button in green -->
  <button class="btn" style="background-color: #006400; color: #fff;" onclick="exportTableToExcel('attendanceTable')" title="Export logs to Excel">
    <i class="bi bi-file-earmark-excel"></i> Export to Excel
  </button>
</div>


  <!-- ✅ Logs Table -->
  <div class="card shadow-sm">
    <div class="card-body">
      <h5 class="card-title mb-3"><i class="bi bi-journal-text"></i> Logs for <?php echo htmlspecialchars($filter_date); ?></h5>
      <div class="table-responsive">
        <table class="table table-striped table-bordered table-hover align-middle" id="attendanceTable">
          <thead class="table-primary text-center">
            <tr>
              <th>#</th>
              <th>Student ID</th>
              <th>Name</th>
              <th>Course</th>
              <th>Year & Section</th>
              <th>Action</th>
              <th>Time</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($logs)): ?>
              <?php foreach ($logs as $i => $log): ?>
              <tr>
  <td><?php echo $i+1; ?></td>
  <td><span class="fw-bold text-dark"><?php echo htmlspecialchars($log['student_id']); ?></span></td>
  <td><?php echo htmlspecialchars($log['name']); ?></td>
  <td class="text-center"><?php echo htmlspecialchars($log['course']); ?></td>
  <td class="text-center"><?php echo htmlspecialchars($log['year_section']); ?></td>
  <td class="text-center">
    <?php if ($log['action'] === 'login'): ?>
      <span class="badge badge-login"><i class="bi bi-box-arrow-in-right"></i> LOGIN</span>
    <?php else: ?>
      <span class="badge badge-logout"><i class="bi bi-box-arrow-left"></i> LOGOUT</span>
    <?php endif; ?>
  </td>
  <td class="text-center log-time" data-time="<?php echo htmlspecialchars($log['log_time']); ?>">
    <i class="bi bi-clock"></i> Loading…
  </td>
</tr>

              <?php endforeach; ?>
            <?php else: ?>
              <tr><td colspan="7" class="text-center text-muted"><i class="bi bi-exclamation-circle"></i> No entries found.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- ✅ Convert timestamp to Philippine Time -->
<script>
document.addEventListener("DOMContentLoaded", function() {
  const timeCells = document.querySelectorAll(".log-time");
  timeCells.forEach(cell => {
    const timeStr = cell.getAttribute("data-time");
    if (timeStr) {
      const isoStr = timeStr.replace(" ", "T") + "+08:00";
      const phTime = new Date(isoStr);
      if (!isNaN(phTime)) {
        const options = { 
          year: 'numeric', month: 'short', day: 'numeric',
          hour: '2-digit', minute: '2-digit', second: '2-digit',
          hour12: true
        };
        cell.innerHTML = `<i class="bi bi-clock"></i> ${phTime.toLocaleString('en-PH', options)}`;
      } else {
        cell.innerHTML = `<i class="bi bi-clock"></i> Invalid Date`;
      }
    }
  });
});

// ✅ Export to Excel
function exportTableToExcel(tableID) {
    let table = document.getElementById(tableID);
    let html = table.outerHTML.replace(/ /g, '%20');
    let filename = 'attendance_logs_<?php echo $filter_date; ?>.xls';
    let uri = 'data:application/vnd.ms-excel,' + html;

    let link = document.createElement('a');
    link.href = uri;
    link.style.display = 'none';
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
