<?php
session_start();
require 'db.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';

    if (!$username || !$password || !in_array($role, ['instructor','pacd'])) {
        $error = "All fields are required.";
    } else {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $hash, $role);
        if ($stmt->execute()) {
            $success = "✅ Account created. You can now <a href='login.php'>log in</a>.";
        } else {
            $error = "⚠️ Failed to create account. Username might be taken.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Register — Attendance Monitoring System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap & Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body {
      background: #f8f9fa;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      font-family: "Segoe UI", sans-serif;
    }
    .card {
      border-radius: 15px;
      border: none;
      background: white;
    }
    .card-header {
      background: #198754;
      color: white;
      text-align: center;
      padding: 1.2rem;
      border-radius: 15px 15px 0 0;
    }
    .form-control, .form-select {
      border-radius: 10px;
      padding: 12px;
      font-size: 1rem;
    }
    .btn-success {
      border-radius: 10px;
      font-size: 1.1rem;
      padding: 12px;
      background: #198754;
      border: none;
      transition: 0.3s;
    }
    .btn-success:hover {
      background: #157347;
    }
    .input-group-text {
      background: #f1f1f1;
      border-right: 0;
    }
    .input-group .form-control {
      border-left: 0;
    }
    .toggle-password {
      cursor: pointer;
      border-left: 0;
    }
  </style>
</head>
<body>

<div class="card shadow-lg" style="width: 100%; max-width: 480px;">
  <div class="card-header">
    <h3><i class="bi bi-person-plus"></i> Create Account</h3>
  </div>
  <div class="card-body p-4">
    <?php if ($success): ?>
      <div class="alert alert-success text-center"><?php echo $success; ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
      <div class="alert alert-danger text-center"><?php echo $error; ?></div>
    <?php endif; ?>
    <form method="POST">
      <div class="mb-3">
        <label class="form-label">Username</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-person"></i></span>
          <input type="text" name="username" class="form-control" placeholder="Choose a username" required>
        </div>
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-lock"></i></span>
          <input type="password" name="password" id="password" class="form-control" placeholder="Enter a password" required>
          <span class="input-group-text toggle-password" onclick="togglePassword()">
            <i class="bi bi-eye" id="toggleIcon"></i>
          </span>
        </div>
      </div>
      <div class="mb-3">
        <label class="form-label">Role</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-people"></i></span>
          <select name="role" class="form-select" required>
            <option value="">-- Select Role --</option>
            <option value="instructor">Instructor</option>
            <option value="pacd">PACD</option>
          </select>
        </div>
      </div>
      <button class="btn btn-success w-100"><i class="bi bi-check-circle"></i> Register</button>
    </form>
    <hr>
    <p class="text-center mb-0">
      <i class="bi bi-box-arrow-in-left"></i> Already have an account? 
      <a href="login.php" class="text-decoration-none">Login here</a>
    </p>
  </div>
</div>

<script>
function togglePassword() {
  const passwordInput = document.getElementById("password");
  const toggleIcon = document.getElementById("toggleIcon");
  if (passwordInput.type === "password") {
    passwordInput.type = "text";
    toggleIcon.classList.remove("bi-eye");
    toggleIcon.classList.add("bi-eye-slash");
  } else {
    passwordInput.type = "password";
    toggleIcon.classList.remove("bi-eye-slash");
    toggleIcon.classList.add("bi-eye");
  }
}
</script>

</body>
</html>
